#include "sapi/embed/php_embed.h"
#include <emscripten.h>
#include <stdlib.h>

#include "zend_globals_macros.h"
#include "zend_exceptions.h"
#include "zend_closures.h"

int main() {
    return 0;
}

int MODULE_STARTED = 0;
int REQUEST_STARTED = 0;

void ensure_module_started() {
    if (!MODULE_STARTED) {
        setenv("USE_ZEND_ALLOC", "0", 1);
        php_embed_init(0, NULL); // Starts Module AND Request
        MODULE_STARTED = 1;
        REQUEST_STARTED = 1;
    }
}

void ensure_request_started() {
    if (!MODULE_STARTED) {
        ensure_module_started();
    } else if (!REQUEST_STARTED) {
        if (php_request_startup() == FAILURE) {
            // If request startup fails, try to hard reset
            php_module_shutdown();
            sapi_shutdown();
            MODULE_STARTED = 0;
            ensure_module_started();
        }
        REQUEST_STARTED = 1;
    }
}

void ensure_request_shutdown() {
    if (REQUEST_STARTED) {
        php_request_shutdown((void *) 0);
        REQUEST_STARTED = 0;
    }
}

void full_shutdown() {
    if (MODULE_STARTED) {
        if (REQUEST_STARTED) {
            php_embed_shutdown(); // Handles Request + Module shutdown
        } else {
            php_module_shutdown();
            sapi_shutdown();
        }
        MODULE_STARTED = 0;
        REQUEST_STARTED = 0;
    }
}

void phpw_flush() {
    fprintf(stdout, "\n");
    fprintf(stderr, "\n");
}

void EMSCRIPTEN_KEEPALIVE phpw_eval(char *code) {
    ensure_request_started();
    zend_eval_string(code, NULL, "phpw_eval run script");
    if (EG(exception)) {
        zend_exception_error(EG(exception), E_ERROR);
        zend_clear_exception();
    }
    phpw_flush();
    full_shutdown();
}

void EMSCRIPTEN_KEEPALIVE phpw_run(char *file) {
    full_shutdown(); // Ensure clean slate
    ensure_request_started();
    
    zend_file_handle file_handle;
    zend_stream_init_filename(&file_handle, file);
    int result = php_execute_script(&file_handle);
    if (EG(exception)) {
        zend_exception_error(EG(exception), E_ERROR);
        zend_clear_exception();
    }
    zend_destroy_file_handle(&file_handle);
    phpw_flush();
    full_shutdown();
}

void EMSCRIPTEN_KEEPALIVE phpw_run_keepalive(char *file) {
    ensure_request_started();
    
    zend_file_handle file_handle;
    zend_stream_init_filename(&file_handle, file);
    int result = php_execute_script(&file_handle);
    if (EG(exception)) {
        zend_exception_error(EG(exception), E_ERROR);
        zend_clear_exception();
    }
    
    php_output_flush();
    sapi_flush();
    zend_destroy_file_handle(&file_handle);
    phpw_flush();

}
